# Seatflow Ticket Booking System

Seatflow is a full-stack movie and concert ticketing system with live seat maps, protected temporary holds, QR tickets, cancellation, FIFO waitlists, and role-based operations.

## Stack

- React + Vite client
- Express + TypeScript API
- PostgreSQL + Prisma data layer
- Redis + BullMQ delayed expiry jobs
- Socket.IO real-time seat updates
- Resend transactional email API

## Run locally

1. Install Node.js 20+, PostgreSQL, and Redis.
2. Copy `server/.env.example` to `server/.env` and `client/.env.example` to `client/.env`.
3. Set `DATABASE_URL`, `REDIS_URL`, and a strong `JWT_SECRET` in `server/.env`.
4. Run `npm install`, then `npm run prisma:generate -w server` and `npm run prisma:migrate -w server`.
5. Start both apps: `npm run dev`.

Client: `http://localhost:5173`. API: `http://localhost:4000`. Health check: `GET /health`.

## Email and QR tickets

The QR payload is exactly the booking reference (for example `BK-2026-D418AD2B`). Every newly confirmed booking generates a QR PNG, returns it to the client, displays it in **My tickets**, and sends it as both an inline ticket and an email attachment when Resend is configured.

Create a free Resend account, verify a sending domain (or use its test sender for the account owner), create an API key, then set:

```env
RESEND_API_KEY="re_..."
EMAIL_FROM="Seatflow Tickets <tickets@your-verified-domain.com>"
```

Without those two variables, development remains safe: a preview is logged and a successful booking is never rolled back because an email provider is unavailable. See [Resend’s send-email API](https://resend.com/docs/api-reference/emails/send-email) for account/domain requirements.

## Roles

- `CUSTOMER`: browse, hold, confirm, cancel, waitlist, and view tickets.
- `ORGANISER`: create events and view summaries only for events they own.
- `ADMIN`: create venues, create events, and view any event summary.

Registration intentionally permits only customer or organiser roles. Promote the first trusted admin directly in the database for a demo; never expose admin self-registration publicly.

## Checks before submission

```bash
npm run test
npm run build
```

Run the manual integration checklist in [docs/verification-checklist.md](docs/verification-checklist.md) against the deployed environment. Architecture, data model, API reference, deployment steps, and the under-800-word design write-up are in [docs](docs/).
