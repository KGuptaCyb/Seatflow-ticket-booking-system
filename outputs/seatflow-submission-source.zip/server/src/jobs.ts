import { Queue, Worker } from 'bullmq';
import { randomUUID } from 'node:crypto';
import { Redis } from 'ioredis';
import { prisma } from './db.js';
import { config } from './config.js';
import { sendEmail } from './email.js';
import { eventChanged } from './realtime.js';

const redisUrl = new URL(config.redis);
const connection = new Redis(config.redis, { maxRetriesPerRequest: null, ...(redisUrl.protocol === 'rediss:' ? { tls: {} } : {}) });
export const expiryQueue = new Queue('expiry', { connection });
export const scheduleHold = (seatId: string, expires: Date) => expiryQueue.add('hold', { seatId }, { delay: Math.max(0, +expires - Date.now()), jobId: `hold:${seatId}:${+expires}` });
export const scheduleOffer = (offerId: string, expires: Date) => expiryQueue.add('offer', { offerId }, { delay: Math.max(0, +expires - Date.now()), jobId: `offer:${offerId}` });

/** FIFO, category-scoped allocation. Both the seat and queue row are locked,
 * preventing duplicate offers when cancellation and expiry jobs overlap. */
export async function offerNext(eventSeatId: string) {
  const expiresAt = new Date(Date.now() + config.offerMs);
  const allocation = await prisma.$transaction(async (tx) => {
    const seats = await tx.$queryRaw<{ id: string; eventId: string; category: string; status: string }[]>`SELECT id,"eventId",category,status FROM "EventSeat" WHERE id=${eventSeatId} FOR UPDATE`;
    const seat = seats[0];
    if (!seat || seat.status !== 'AVAILABLE') return null;
    const candidates = await tx.$queryRaw<{ id: string; email: string }[]>`SELECT w.id,u.email FROM "Waitlist" w JOIN "User" u ON u.id=w."userId" WHERE w."eventId"=${seat.eventId} AND w.category=${seat.category} AND w.active=true ORDER BY w."createdAt" ASC LIMIT 1 FOR UPDATE OF w SKIP LOCKED`;
    const candidate = candidates[0];
    if (!candidate) return null;
    await tx.eventSeat.update({ where: { id: seat.id }, data: { status: 'OFFERED' } });
    const offer = await tx.waitlistOffer.create({ data: { waitlistId: candidate.id, eventSeatId: seat.id, token: `${randomUUID()}${randomUUID()}`, expiresAt } });
    return { offer, eventId: seat.eventId, email: candidate.email };
  });
  if (!allocation) return null;
  await scheduleOffer(allocation.offer.id, expiresAt);
  eventChanged(allocation.eventId, [{ id: eventSeatId, status: 'OFFERED' }]);
  try { await sendEmail({ to: allocation.email, subject: 'A Seatflow waitlist seat is available', html: `<p>A seat is available for you. Open My Tickets and accept your offer before <strong>${expiresAt.toLocaleString()}</strong>.</p>` }); }
  catch (error) { console.error(`[email] waitlist offer delivery failed for ${allocation.offer.id}`, error); }
  return allocation.offer;
}

export const startWorker = () => new Worker('expiry', async job => {
  if (job.name === 'hold') {
    const released = await prisma.eventSeat.updateMany({ where: { id: job.data.seatId, status: 'HELD', holdExpiresAt: { lte: new Date() } }, data: { status: 'AVAILABLE', heldById: null, holdExpiresAt: null } });
    if (!released.count) return;
    const seat = await prisma.eventSeat.findUnique({ where: { id: job.data.seatId } });
    if (!seat) return;
    eventChanged(seat.eventId, [{ id: seat.id, status: 'AVAILABLE' }]);
    await offerNext(seat.id);
    return;
  }
  const expired = await prisma.$transaction(async tx => {
    const offers = await tx.$queryRaw<{ id: string; eventSeatId: string; eventId: string }[]>`SELECT o.id,o."eventSeatId",s."eventId" FROM "WaitlistOffer" o JOIN "EventSeat" s ON s.id=o."eventSeatId" WHERE o.id=${job.data.offerId} AND o.status='PENDING' AND o."expiresAt"<=NOW() FOR UPDATE OF o,s`;
    const offer = offers[0]; if (!offer) return null;
    await tx.waitlistOffer.update({ where: { id: offer.id }, data: { status: 'EXPIRED' } });
    await tx.eventSeat.update({ where: { id: offer.eventSeatId }, data: { status: 'AVAILABLE', heldById: null, holdExpiresAt: null } });
    return offer;
  });
  if (!expired) return;
  eventChanged(expired.eventId, [{ id: expired.eventSeatId, status: 'AVAILABLE' }]);
  await offerNext(expired.eventSeatId);
}, { connection });
