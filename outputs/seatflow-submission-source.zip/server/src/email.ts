import { config } from './config.js';

type Attachment = {
  filename: string;
  content: string;
  content_type: string;
};

type Email = {
  to: string;
  subject: string;
  html: string;
  attachments?: Attachment[];
};

/**
 * Sends transactional email through Resend's HTTPS API.  Keeping this small
 * and dependency-free makes local development safe: without credentials we
 * log the message instead of making a network request.
 */
export async function sendEmail(message: Email) {
  if (!config.resendApiKey || !config.emailFrom) {
    console.info(`[email preview] ${message.subject} -> ${message.to}`);
    return { delivered: false, reason: 'Email is not configured' };
  }

  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${config.resendApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ from: config.emailFrom, ...message }),
  });

  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`Resend rejected the email (${response.status}): ${detail}`);
  }

  return { delivered: true, ...(await response.json()) };
}

export function qrPngAttachment(reference: string, qrDataUrl: string): Attachment {
  const base64 = qrDataUrl.split(',', 2)[1];
  if (!base64) throw new Error('Could not prepare QR attachment');
  return {
    filename: `${reference}.png`,
    content: base64,
    content_type: 'image/png',
  };
}

export function ticketEmailHtml(input: {
  name: string;
  reference: string;
  eventTitle: string;
  venue: string;
  startsAt: Date;
  seats: string[];
  qrDataUrl: string;
}) {
  const when = input.startsAt.toLocaleString('en-IN', {
    dateStyle: 'medium',
    timeStyle: 'short',
    timeZone: 'Asia/Kolkata',
  });
  return `<main style="font-family:Arial,sans-serif;color:#1f2933;max-width:560px">
    <h1>Your Seatflow ticket is confirmed</h1>
    <p>Hi ${escapeHtml(input.name)}, your booking reference is <strong>${escapeHtml(input.reference)}</strong>.</p>
    <p><strong>${escapeHtml(input.eventTitle)}</strong><br>${escapeHtml(input.venue)}<br>${when}<br>Seats: ${escapeHtml(input.seats.join(', '))}</p>
    <p>Present this QR ticket at entry. The QR encodes your booking reference: <strong>${escapeHtml(input.reference)}</strong>.</p>
    <img src="${input.qrDataUrl}" width="180" height="180" alt="QR ticket for ${escapeHtml(input.reference)}" />
  </main>`;
}

const escapeHtml = (value: string) =>
  value.replace(/[&<>'"]/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;',
  })[character]!);
