import 'dotenv/config';
export const config = {
  port: Number(process.env.PORT || 4000),
  jwt: process.env.JWT_SECRET || 'development-only-change-me-please-123456',
  clientUrl: process.env.CLIENT_URL || 'http://localhost:5173',
  redis: process.env.REDIS_URL || 'redis://localhost:6379',
  holdMs: Number(process.env.SEAT_HOLD_TTL_MINUTES || 10) * 60000,
  offerMs: Number(process.env.WAITLIST_OFFER_TTL_MINUTES || 10) * 60000,
  resendApiKey: process.env.RESEND_API_KEY,
  emailFrom: process.env.EMAIL_FROM,
};
