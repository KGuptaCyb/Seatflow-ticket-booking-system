import { Router } from 'express';
import QRCode from 'qrcode';
import { randomUUID } from 'node:crypto';

import { prisma } from '../db.js';
import { asyncRoute, ApiError } from '../errors.js';
import { authenticate, AuthRequest } from '../middleware/auth.js';
import { eventChanged } from '../realtime.js';
import { offerNext } from '../jobs.js';
import { qrPngAttachment, sendEmail, ticketEmailHtml } from '../email.js';

const r = Router();

const reference = () =>
  `BK-${new Date().getFullYear()}-${randomUUID()
    .replace(/-/g, '')
    .slice(0, 8)
    .toUpperCase()}`;

const transactionOptions = {
  maxWait: 10000,
  timeout: 15000,
};

r.post(
  '/',
  authenticate,
  asyncRoute(async (req: AuthRequest, res) => {
    const seatIds = req.body.seatIds as string[];

    if (!Array.isArray(seatIds) || !seatIds.length) {
      throw new ApiError(400, 'Seat IDs required');
    }

    const uniqueSeatIds = [...new Set(seatIds)];

    const booking = await prisma.$transaction(
      async (tx) => {
        /*
         * Lock the requested seats so two customers cannot
         * simultaneously book/modify the same seats.
         */
        const locked = await tx.$queryRaw<
          {
            id: string;
            status: string;
            heldById: string | null;
            holdExpiresAt: Date | null;
          }[]
        >`
          SELECT
            id,
            status,
            "heldById",
            "holdExpiresAt"
          FROM "EventSeat"
          WHERE id = ANY(${uniqueSeatIds}::text[])
          FOR UPDATE
        `;

        /*
         * Every requested seat must:
         * - exist
         * - currently be HELD
         * - be held by the current customer
         * - have a valid, non-expired hold
         */
        if (
          locked.length !== uniqueSeatIds.length ||
          locked.some(
            (s) =>
              s.status !== 'HELD' ||
              s.heldById !== req.user!.id ||
              !s.holdExpiresAt ||
              s.holdExpiresAt <= new Date()
          )
        ) {
          throw new ApiError(
            409,
            'Your seat hold has expired or is invalid'
          );
        }

        const seats = await tx.eventSeat.findMany({
          where: {
            id: {
              in: uniqueSeatIds,
            },
          },
          include: {
            seat: true,
          },
        });

        if (!seats.length) {
          throw new ApiError(404, 'Seats not found');
        }

        const eventId = seats[0].eventId;

        /*
         * All seats in a booking must belong to the same event.
         */
        if (seats.some((s) => s.eventId !== eventId)) {
          throw new ApiError(
            400,
            'Seats must belong to one event'
          );
        }

        const total = seats.reduce(
          (sum, seat) => sum + seat.price,
          0
        );

        /*
         * Create the booking while the seat locks are still held.
         */
        const created = await tx.booking.create({
          data: {
            reference: reference(),
            userId: req.user!.id,
            eventId,
            total,
            qrToken: randomUUID(),

            seats: {
              create: seats.map((seat) => ({
                eventSeatId: seat.id,
                price: seat.price,
              })),
            },
          },

          include: {
            event: {
              include: {
                venue: true,
              },
            },

            user: {
              select: { name: true },
            },

            seats: {
              include: {
                eventSeat: {
                  include: {
                    seat: true,
                  },
                },
              },
            },
          },
        });

        /*
         * Convert the held seats into booked seats.
         */
        await tx.eventSeat.updateMany({
          where: {
            id: {
              in: uniqueSeatIds,
            },
          },

          data: {
            status: 'BOOKED',
            heldById: null,
            holdExpiresAt: null,
          },
        });

        return created;
      },
      transactionOptions
    );

    /*
     * Generate the QR ticket after the database transaction
     * has successfully completed.
     */
    // The reference is deliberately the entire QR payload: it is what venue
    // staff need to scan and reconcile with the booking record.
    const qrCode = await QRCode.toDataURL(booking.reference);

    /*
     * Tell connected clients that these seats are now booked.
     */
    eventChanged(
      booking.eventId,
      uniqueSeatIds.map((id) => ({
        id,
        status: 'BOOKED',
      }))
    );

    // A mail outage must never roll back a confirmed, paid booking. Delivery
    // failures are logged for retry/monitoring while the QR remains available
    // from My Tickets.
    try {
      await sendEmail({
        to: req.user!.email,
        subject: `Your Seatflow ticket: ${booking.reference}`,
        html: ticketEmailHtml({
          name: booking.user.name,
          reference: booking.reference,
          eventTitle: booking.event.title,
          venue: booking.event.venue.name,
          startsAt: booking.event.startsAt,
          seats: booking.seats.map((seat) => `${seat.eventSeat.seat.row}${seat.eventSeat.seat.number}`),
          qrDataUrl: qrCode,
        }),
        attachments: [qrPngAttachment(booking.reference, qrCode)],
      });
    } catch (error) {
      console.error(`[email] confirmation delivery failed for ${booking.reference}`, error);
    }

    res.status(201).json({
      success: true,
      data: {
        booking,
        qrCode,
      },
    });
  })
);

r.get(
  '/',
  authenticate,
  asyncRoute(async (req: AuthRequest, res) => {
    const bookings = await prisma.booking.findMany({
      where: {
        userId: req.user!.id,
      },

      include: {
        event: {
          include: {
            venue: true,
          },
        },

        seats: {
          include: {
            eventSeat: {
              include: {
                seat: true,
              },
            },
          },
        },
      },

      orderBy: {
        createdAt: 'desc',
      },
    });

    const tickets = await Promise.all(bookings.map(async (booking) => ({
      ...booking,
      // QR codes are derived on demand, so no base64 blob is stored in PostgreSQL.
      qrCode: booking.status === 'CONFIRMED' ? await QRCode.toDataURL(booking.reference) : null,
    })));

    res.json({
      success: true,
      data: tickets,
    });
  })
);

r.post(
  '/:id/cancel',
  authenticate,
  asyncRoute(async (req: AuthRequest, res) => {
    const bookingId = String(req.params.id);

    const booking = await prisma.$transaction(
      async (tx) => {
        const b = await tx.booking.findUnique({
          where: {
            id: bookingId,
          },

          include: {
            seats: {
              include: {
                eventSeat: true,
              },
            },
          },
        });

        if (!b) {
          throw new ApiError(404, 'Booking not found');
        }

        if (b.userId !== req.user!.id) {
          throw new ApiError(403, 'Not your booking');
        }

        if (b.status === 'CANCELLED') {
          throw new ApiError(
            409,
            'Booking already cancelled'
          );
        }

        await tx.booking.update({
          where: {
            id: b.id,
          },

          data: {
            status: 'CANCELLED',
          },
        });

        await tx.eventSeat.updateMany({
          where: {
            id: {
              in: b.seats.map(
                (seat) => seat.eventSeatId
              ),
            },
          },

          data: {
            status: 'AVAILABLE',
            heldById: null,
            holdExpiresAt: null,
          },
        });

        return b;
      },
      transactionOptions
    );

    /*
     * Notify connected clients that the seats are available.
     */
    eventChanged(
      booking.eventId,
      booking.seats.map((seat) => ({
        id: seat.eventSeatId,
        status: 'AVAILABLE',
      }))
    );

    /*
     * Try to give the newly available seats to
     * the next waitlisted customer.
     */
    await Promise.all(
      booking.seats.map((seat) =>
        offerNext(seat.eventSeatId)
      )
    );

    res.json({
      success: true,
      data: booking,
    });
  })
);

export default r;
