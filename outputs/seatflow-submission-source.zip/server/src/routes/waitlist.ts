import { Router } from 'express';
import { prisma } from '../db.js';
import { asyncRoute, ApiError } from '../errors.js';
import { authenticate, AuthRequest } from '../middleware/auth.js';
import { eventChanged } from '../realtime.js';
import { scheduleHold } from '../jobs.js';

const r = Router();

r.post('/events/:id/waitlist', authenticate, asyncRoute(async (req: AuthRequest, res) => {
  const eventId = String(req.params.id), category = String(req.body.category || '');
  if (!category) throw new ApiError(400, 'Category required');
  const waitlist = await prisma.waitlist.upsert({ where: { eventId_userId_category: { eventId, userId: req.user!.id, category } }, create: { eventId, userId: req.user!.id, category }, update: { active: true } });
  res.status(201).json({ success: true, data: waitlist });
}));

r.get('/events/:id/waitlist/status', authenticate, asyncRoute(async (req: AuthRequest, res) => {
  const data = await prisma.waitlist.findMany({ where: { eventId: String(req.params.id), userId: req.user!.id }, include: { offers: { include: { eventSeat: { include: { seat: true } } }, orderBy: { createdAt: 'desc' } } } });
  res.json({ success: true, data });
}));

// Accepting an offer turns it into the normal customer-specific hold. It is
// atomically conditional on its expiry and the seat still being OFFERED.
r.post('/waitlist/offers/:token/accept', authenticate, asyncRoute(async (req: AuthRequest, res) => {
  const token = String(req.params.token);
  const accepted = await prisma.$transaction(async tx => {
    const rows = await tx.$queryRaw<{ id: string; waitlistId: string; eventSeatId: string; eventId: string; expiresAt: Date; userId: string; status: string }[]>`SELECT o.id,o."waitlistId",o."eventSeatId",s."eventId",o."expiresAt",w."userId",o.status FROM "WaitlistOffer" o JOIN "Waitlist" w ON w.id=o."waitlistId" JOIN "EventSeat" s ON s.id=o."eventSeatId" WHERE o.token=${token} FOR UPDATE OF o,w,s`;
    const offer = rows[0];
    if (!offer || offer.userId !== req.user!.id || offer.status !== 'PENDING' || offer.expiresAt <= new Date()) throw new ApiError(409, 'Offer is no longer valid');
    const seat = await tx.eventSeat.updateMany({ where: { id: offer.eventSeatId, status: 'OFFERED' }, data: { status: 'HELD', heldById: req.user!.id, holdExpiresAt: offer.expiresAt } });
    if (seat.count !== 1) throw new ApiError(409, 'Offer is no longer valid');
    await tx.waitlistOffer.update({ where: { id: offer.id }, data: { status: 'ACCEPTED' } });
    await tx.waitlist.update({ where: { id: offer.waitlistId }, data: { active: false } });
    return offer;
  });
  await scheduleHold(accepted.eventSeatId, accepted.expiresAt);
  eventChanged(accepted.eventId, [{ id: accepted.eventSeatId, status: 'HELD', holdExpiresAt: accepted.expiresAt }]);
  res.json({ success: true, data: { seatId: accepted.eventSeatId, expiresAt: accepted.expiresAt } });
}));

export default r;
