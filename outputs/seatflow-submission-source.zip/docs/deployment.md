# Deployment checklist

1. Provision managed PostgreSQL and Redis. Use the provider-issued URI only in `DATABASE_URL`/`REDIS_URL`; TLS Redis endpoints must use `rediss://`.
2. Set production `CLIENT_URL`, `VITE_API_URL`, and `VITE_SOCKET_URL` to the deployed HTTPS origins.
3. Generate a 32+ character `JWT_SECRET`; do not reuse development credentials.
4. Verify a Resend sending domain and configure `RESEND_API_KEY` plus `EMAIL_FROM`.
5. Run `npm ci`, `npm run prisma:generate -w server`, `npm run prisma:migrate -w server`, `npm run build`.
6. Serve `client/dist` from a static host and run `npm run start -w server` in an API service with a persistent Redis connection. Set the API health check to `/health`.
7. Use at least one worker-capable API process. At larger scale, run the BullMQ worker separately with the same Redis queue.
8. Set CORS only to the exact client origin and validate a full booking, email, cancellation, waitlist expiry, and organiser summary after deployment.
