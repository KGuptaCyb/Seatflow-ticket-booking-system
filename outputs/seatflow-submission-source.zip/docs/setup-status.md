# Setup and verification status

Verified on 2026-08-22. No database migrations, resets, or other destructive database commands were run.

## Environment files

- Server template: `server/.env.example`
- Client template: `client/.env.example`

Create untracked `server/.env` and `client/.env` files from those templates. Do not put server secrets in the client file.

## Server variables

| Variable | Required | Used by | Notes |
| --- | --- | --- | --- |
| `DATABASE_URL` | Yes | Prisma schema and `PrismaClient` | PostgreSQL connection string. |
| `REDIS_URL` | Yes to run the API/worker | BullMQ queue and worker | Redis connection string. |
| `JWT_SECRET` | Yes in production | JWT signing/verification | Use a high-entropy secret (at least 32 random characters). |
| `CLIENT_URL` | Yes outside local defaults | Express CORS and Socket.IO CORS | Exact frontend origin, no `/api` suffix. |
| `PORT` | No | HTTP server | Defaults to `4000`. |
| `SEAT_HOLD_TTL_MINUTES` | No | Hold expiry scheduling | Defaults to `10`. |
| `WAITLIST_OFFER_TTL_MINUTES` | No | Waitlist offer expiry scheduling | Defaults to `10`. |
| `RESEND_API_KEY` | Not currently used | None | Present in the template for future provider integration. |
| `EMAIL_FROM` | Not currently used | None | Present in the template for future provider integration. |

The current email implementation is development-safe: it writes booking and waitlist offer messages to the server log using `[email mock]`. No email credentials are required for local development, and adding `RESEND_API_KEY` alone does not enable live delivery yet.

## Client variables

| Variable | Required | Used by |
| --- | --- | --- |
| `VITE_API_URL` | No locally; yes for deployed frontend | Axios base URL; defaults to `http://localhost:4000/api`. |
| `VITE_SOCKET_URL` | No locally; yes for deployed frontend | Socket.IO server URL; defaults to `http://localhost:4000`. |

`VITE_*` values are public browser configuration. Do not place `DATABASE_URL`, `JWT_SECRET`, Redis, or email credentials in `client/.env`.

## Required services

### PostgreSQL

Create a PostgreSQL database (local PostgreSQL, Neon, Supabase, etc.) and provide a valid `DATABASE_URL`, for example:

```env
DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/seatflow?schema=public"
```

The Prisma datasource is configured for PostgreSQL and the schema validates. There is currently no migration directory, so the first migration must be created intentionally after connecting a development database:

```bash
npm run prisma:migrate -w server -- --name init
```

PostgreSQL connectivity has **not** been tested in this verification phase.

### Redis / BullMQ

Create a Redis instance (local Redis, Upstash, Redis Cloud, etc.) and provide:

```env
REDIS_URL="redis://localhost:6379"
```

The BullMQ queue and worker are configured in `server/src/jobs.ts`. The worker is started by `server/src/index.ts`, so there is no separate worker command in the current architecture; starting the backend starts both the API and worker.

Redis connectivity has **not** been tested in this verification phase.

## Scripts

### Server (`server/package.json`)

- `npm run dev -w server` — watch-mode API and embedded BullMQ worker
- `npm run build -w server` — TypeScript compilation
- `npm run start -w server` — run built API and embedded worker
- `npm run test -w server` — Vitest (no test files currently exist)
- `npm run prisma:generate -w server` — Prisma Client generation
- `npm run prisma:migrate -w server` — Prisma development migration

There is no Prisma seed script or `server/prisma/seed.ts`. The stale seed command was removed so it no longer points to a nonexistent file.

### Client (`client/package.json`)

- `npm run dev -w client` — Vite development server
- `npm run build -w client` — TypeScript and Vite production build

## Commands to run

After creating PostgreSQL and Redis and adding both `.env` files:

```bash
npx prisma generate --schema server/prisma/schema.prisma
npm run prisma:migrate -w server -- --name init
npm run dev -w server
npm run dev -w client
```

Or start both development processes together:

```bash
npm run dev
```

## Validation results

| Check | Status | Detail |
| --- | --- | --- |
| `npx prisma validate --schema server/prisma/schema.prisma` | Passed | Run with a placeholder `DATABASE_URL`; it does not connect to PostgreSQL. |
| Prisma schema configuration | Corrected | Rewrote invalid single-line Prisma declarations into valid syntax. |
| `npx prisma generate --schema server/prisma/schema.prisma` | Blocked by environment | Prisma attempted to fetch `libquery_engine` from `binaries.prisma.sh`, but DNS resolution failed (`ENOTFOUND`). |
| Client production build | Passed | `npm run build -w client` completed successfully. |
| Server TypeScript build | Blocked / failing | The generated Prisma Client is unavailable due to the engine-download failure; the build reports missing Prisma generated exports and cascaded type errors. It also reports an `ioredis` constructor typing issue that should be addressed after generation is available. |
| Socket.IO | Structurally configured | Server uses HTTP + Socket.IO and event rooms; client connects using `VITE_SOCKET_URL`. Runtime connectivity has not been tested because the backend requires Redis and PostgreSQL. |

## Open issues

1. Restore network access to `binaries.prisma.sh` (or pre-provision the matching Prisma engine) and rerun Prisma Client generation.
2. With generated client available, rerun `npm run build -w server`; fix the remaining `ioredis` import/type error if it persists.
3. Create a PostgreSQL database and Redis instance, then run the initial migration and perform actual service connectivity tests.
4. Live Resend delivery is not implemented yet; current email behavior is intentional development logging.
